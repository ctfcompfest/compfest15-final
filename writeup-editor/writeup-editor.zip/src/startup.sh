#!/usr/bin/env sh
npm run buildhot&
npm run starthot