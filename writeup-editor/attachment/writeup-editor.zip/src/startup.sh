#!/usr/bin/env sh
yarn buildhot&
yarn starthot